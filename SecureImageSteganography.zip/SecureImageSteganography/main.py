"""Entry point: run with  `python main.py`  from the project folder."""

import sys


def enable_high_dpi():
    """On Windows, stop the window from looking blurry on high-DPI screens."""
    if sys.platform.startswith("win"):
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass  # purely cosmetic - safe to ignore


if __name__ == "__main__":
    enable_high_dpi()
    from gui.app import run
    run()
