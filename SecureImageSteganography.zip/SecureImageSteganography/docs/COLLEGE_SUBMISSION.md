# Secure Image Steganography Using Python — College Submission Material

## 1. Project Abstract

This project presents a desktop application, built in Python with a Tkinter graphical
interface, that hides secret text messages inside digital images and recovers them
later. It uses the Least Significant Bit (LSB) technique, replacing the lowest bit of
each red, green and blue value with one bit of the message, which changes any colour
value by at most 1 and is not visible to the human eye. To protect the content, the
message can be encrypted with a user password before embedding, using Scrypt key
derivation with a random salt and Fernet authenticated encryption. The program saves
results as lossless PNG files, validates capacity and input, detects corrupted or
message-free images, and compares original and encoded images using MSE and PSNR with
charts. The logic is separated from the interface and covered by automated tests.

## 2. Problem Statement

Encryption hides *what* a message says but not *that* a message exists. A user who wants
to exchange confidential information discreetly needs a way to conceal the message inside
an ordinary-looking file, and ideally also protect its contents. Existing tools are often
complex, closed-source or unsafe (for example saving to JPEG, which destroys hidden data).
This project provides a simple, safe and understandable tool that does both.

## 3. Objectives

1. Implement LSB steganography for text in RGB/RGBA images.
2. Save encoded images as lossless PNG without modifying the original.
3. Add password-based authenticated encryption with a unique salt per message.
4. Detect images without hidden data, corrupted data and wrong passwords gracefully.
5. Measure the visual impact using MSE and PSNR.
6. Provide a user-friendly GUI with validation and clear error messages.
7. Write modular, documented and tested code.

## 4. Existing System and Proposed System

**Existing systems**
- Plain encryption tools: content is hidden but the existence of a secret is obvious.
- Online steganography websites: require uploading private images/messages to a server.
- Basic LSB scripts: often no encryption, no length header, no validation, no quality analysis, command-line only.

**Proposed system**
- Works fully offline on the user's computer.
- Combines encryption (confidentiality + tamper detection) with LSB hiding (concealment).
- Versioned payload with magic identifier, length and CRC32 checksum.
- Capacity check, input validation and friendly errors.
- Built-in MSE/PSNR comparison and difference map.
- GUI plus automated test suite.

## 5. Software and Hardware Requirements

| Software | Requirement |
|---|---|
| Operating system | Windows 10/11 (also runs on Linux/macOS with Tkinter installed) |
| Language | Python 3.10 or newer (tested on 3.12) |
| Libraries | Pillow, NumPy, cryptography, Matplotlib (see `requirements.txt`) |
| Editor | VS Code with the Python extension (any editor works) |

| Hardware | Minimum |
|---|---|
| Processor | Dual-core, 1.5 GHz or better |
| RAM | 4 GB (encryption key derivation uses about 16 MB briefly) |
| Disk | 200 MB free (Python + libraries) |
| Display | 1024 x 768 or higher |

## 6. System Architecture Diagram

```
+--------------------------------------------------------------+
|                      GUI layer (gui/app.py)                   |
|  Home | Hide page | Extract page | Compare page | About page   |
+------------------------------+-------------------------------+
                               | calls functions, shows results/errors
+------------------------------v-------------------------------+
|              Logic layer (steganography package)             |
|                                                              |
|  validators.py --> encoder.py ---+--> payload.py             |
|        |                         |                           |
|        |           encryption.py-+                           |
|        +----------> decoder.py --+--> payload.py             |
|                      image_metrics.py                        |
|                      errors.py (shared exceptions)           |
+------------------------------+-------------------------------+
                               |
+------------------------------v-------------------------------+
|     Libraries: Pillow (read/save)  NumPy (pixels, MSE)       |
|     cryptography (Scrypt, Fernet)  Matplotlib (charts)       |
+------------------------------+-------------------------------+
                               |
                    Image files on disk (PNG output)
```

The GUI never touches pixels or keys; it only calls the logic layer. Errors travel upward as
custom exceptions that the GUI turns into message boxes.

## 7. Algorithm and Flowchart

### Encoding algorithm
1. Validate image path/type, message (non-empty) and output path (.png).
2. Load the image; convert to RGB (keep alpha for RGBA).
3. If a password is given: generate a random salt, derive a key with Scrypt, encrypt the message with Fernet; body = salt + token. Otherwise body = UTF-8 bytes.
4. Build payload = header (magic, version, flags, length, CRC32) + body.
5. If payload size > capacity (width x height x 3 / 8 bytes), stop with an error.
6. Convert payload to bits. For each bit, replace the LSB of the next R, G or B value: `value = (value & 0xFE) | bit`.
7. Save as a new PNG (never the original file).

### Decoding algorithm
1. Validate that the file is a readable PNG/BMP (JPEG is rejected).
2. Read the LSBs of the first 14 bytes (header). If the magic is not `SIS1`, report "no hidden message".
3. Check the declared length against the image capacity; if too large, report corruption.
4. Read exactly `length` body bytes and verify the CRC32.
5. If the encrypted flag is set: require a password, derive the key with the stored salt, decrypt (wrong password or tampering is rejected).
6. Decode UTF-8 and show the message.

### Flowchart (encoding)

```
        [Start]
           |
   [Select image + type message]
           |
     <Message empty?> --yes--> [Error: empty message] --> [End]
           | no
     <Use password?> --yes--> [Salt + Scrypt key + Fernet encrypt]
           | no                          |
           +------------<-----------------+
           |
   [Build payload: header + body]
           |
  <Payload fits in capacity?> --no--> [Error: too large] --> [End]
           | yes
   [Replace LSBs of R,G,B values with payload bits]
           |
   [Save as new PNG]
           |
   [Show success message] --> [End]
```

### Flowchart (decoding)

```
 [Start] -> [Select PNG] -> [Read header bits]
     -> <Magic = SIS1?> --no--> [Error: no hidden message] -> [End]
     -> <Length <= capacity?> --no--> [Error: corrupted] -> [End]
     -> [Read body] -> <CRC ok?> --no--> [Error: corrupted] -> [End]
     -> <Encrypted?> --no--> [Show text] -> [End]
           | yes
     -> <Password given?> --no--> [Ask for password]
     -> [Scrypt + Fernet decrypt] -> <Valid?> --no--> [Error: wrong password]
     -> [Show text] -> [End]
```

## 8. Data-Flow Diagram

**Level 0 (context)**

```
 User --(image, message, password)--> [ Secure Image Steganography ] --(encoded PNG)--> User
 User --(encoded PNG, password)-----> [ Secure Image Steganography ] --(message / error)--> User
 User --(original + encoded)--------> [ Secure Image Steganography ] --(MSE, PSNR, charts)--> User
```

**Level 1**

```
 (1) Validate input ---> (2) Encrypt (optional) ---> (3) Build payload ---> (4) Embed in LSBs ---> (5) Save PNG
                                                                                                      |
 (6) Load PNG ---> (7) Read header + verify ---> (8) Decrypt (optional) ---> (9) Show message          v
                                                                                            [Output folder: PNG file]
 (10) Load two images ---> (11) Compute MSE/PSNR ---> (12) Draw charts + explain results
```

## 9. Module Descriptions

| Module | Responsibility |
|---|---|
| `main.py` | Starts the application (and enables sharp rendering on Windows high-DPI screens) |
| `gui/app.py` | Window, sidebar navigation, Home/Hide/Extract/Compare/About pages, previews, dialogs, status bar and progress indicator. Contains no steganography logic |
| `steganography/errors.py` | Custom exceptions (invalid image, capacity, wrong password, etc.) |
| `steganography/validators.py` | Checks paths, file types, real image content, output extension, non-empty message; builds a non-overwriting output name |
| `steganography/payload.py` | Defines and parses the payload header (magic, version, flags, length, CRC32) |
| `steganography/encryption.py` | Scrypt key derivation with random salt; Fernet encrypt/decrypt |
| `steganography/encoder.py` | Capacity calculation, LSB embedding, saving the PNG |
| `steganography/decoder.py` | Reads the header, validates length/CRC, extracts and decrypts the message |
| `steganography/image_metrics.py` | MSE, PSNR (handles MSE = 0), file size and dimensions, interpretation text |
| `tests/` | Automated unittest suites |

## 10. Test Cases and Expected Results

Run with `python -m unittest -v`. The "Automated test" column names the test that covers the case.

| # | Test case | Expected result | Automated test |
|---|---|---|---|
| 1 | Hide and extract "Hello, World!" | Same text returned | `test_hide_and_extract_normal_message` |
| 2 | Unicode text (Hindi, Chinese, Arabic, emoji) | Identical text | `test_unicode_message` |
| 3 | Multi-line message | Identical text | `test_multiline_message` |
| 4 | Empty / whitespace-only message | Rejected with message | `test_empty_message_rejected` |
| 5 | Message exactly at capacity | Succeeds and extracts correctly | `test_message_exactly_at_capacity` |
| 6 | Message one byte over capacity | CapacityError, no file saved | `test_message_over_capacity_rejected` |
| 7 | Size estimator matches real payload | Equal for plain and encrypted | `test_size_estimate_matches_real_payload` |
| 8 | Original image unchanged | Original bytes identical after encoding | `test_original_image_is_not_modified` |
| 9 | Output path equals input path | Rejected | `test_refuses_to_overwrite_original` |
| 10 | Each colour value changes by at most 1 | Max difference <= 1 | `test_pixels_change_by_at_most_one` |
| 11 | RGBA image | Message recovered, alpha unchanged | `test_rgba_image_keeps_alpha` |
| 12 | Grayscale / palette image | Converted, message recovered | `test_palette_and_grayscale_images` |
| 13 | Correct password | Message recovered | `test_correct_password` |
| 14 | Wrong password | WrongPasswordError | `test_wrong_password_rejected` |
| 15 | Encrypted image, no password given | PasswordRequiredError | `test_missing_password_reported` |
| 16 | Plaintext not visible in encrypted payload | Text absent from raw bytes | `test_message_text_not_visible_in_encrypted_payload` |
| 17 | Modified encrypted data | Rejected (authentication fails) | `test_tampered_encrypted_body_rejected`, `test_modified_ciphertext_rejected` |
| 18 | Unique salt per encryption | Different salts and outputs | `test_unique_salt_each_time` |
| 19 | Image with no hidden message | NoHiddenMessageError | `test_image_without_message`, `test_all_zero_image_without_message` |
| 20 | Image too small for a header | NoHiddenMessageError | `test_tiny_image_without_message` |
| 21 | One flipped bit in the body | CorruptedDataError | `test_corrupted_body_detected` |
| 22 | Header claims huge length | CorruptedDataError, no out-of-range read | `test_bogus_length_in_header_detected` |
| 23 | Missing file / empty path / missing folder | InvalidImageError | `test_invalid_paths` |
| 24 | `.txt` file, fake `.png`, `.jpg` output | InvalidImageError | `test_unsupported_formats` |
| 25 | JPEG given for extraction | Rejected with explanation | `test_jpeg_rejected_for_extraction` |
| 26 | JPEG cover image | Accepted; output saved as PNG | `test_jpeg_cover_accepted_and_saved_as_png` |
| 27 | Saved PNG reopened | Format is PNG; message decodes | `test_saved_png_can_be_reopened_and_decoded` |
| 28 | Identical images | MSE = 0, PSNR = infinity, no error | `test_identical_arrays_zero_mse_infinite_psnr` |
| 29 | Known MSE (difference of 2 everywhere) | MSE = 4.0 | `test_known_mse_value` |
| 30 | No uint8 wrap-around | MSE = 255² for 0 vs 255 | `test_uint8_no_wraparound` |
| 31 | Known PSNR (MSE = 1) | About 48.13 dB | `test_known_psnr_value` |
| 32 | Different image sizes | InvalidImageError | `test_size_mismatch` |

**Manual GUI test cases** (record your own observations; none are pre-filled)

| # | Steps | Expected |
|---|---|---|
| M1 | Hide page > Browse a photo | Preview, dimensions and capacity appear |
| M2 | Type text | Counter shows bytes used and turns red if too large |
| M3 | Hide with no image selected | Warning message |
| M4 | Tick password, enter mismatching confirmation | "Passwords differ" warning |
| M5 | Hide & Save | PNG in `output/`; success dialog |
| M6 | Extract page > select the PNG | "Hidden message detected" label |
| M7 | Extract with wrong password | "Wrong password" error; app keeps running |
| M8 | Extract with correct password | Original message shown |
| M9 | Extract from an unmodified photo | "No hidden message found" |
| M10 | Compare page | Three images, table of metrics, explanation |
| M11 | Clear / Reset buttons | Fields and previews cleared |

## 11. Results and Screenshots Checklist

Take these screenshots from your own run and paste them in the report. Write the actual values you observe; do not copy numbers from this document.

- [ ] Home screen
- [ ] Hide page with an image loaded and the capacity line visible
- [ ] Hide page with a message typed and password enabled
- [ ] Success dialog after saving
- [ ] File Explorer showing the PNG in `output/`
- [ ] Extract page showing the "password-protected" detection label
- [ ] Wrong-password error dialog
- [ ] Successfully extracted message
- [ ] "No hidden message found" error on an ordinary image
- [ ] Oversized-message warning
- [ ] Compare page with original / encoded / difference map and the metrics table
- [ ] Terminal showing `python -m unittest -v` with the final "OK" line
- [ ] Result table: image name, size, message length, MSE, PSNR (fill from your runs)

## 12. Conclusion and Future Scope

**Conclusion.** The project hides and recovers text using LSB steganography in lossless PNG images, adds authenticated password-based encryption, validates capacity and inputs, handles errors without crashing, and quantifies image quality with MSE and PSNR. Separating logic from the interface made the system testable and easy to explain. The project also demonstrates the limits of the technique: LSB hiding is simple but detectable by statistical analysis and fragile against image processing.

**Future scope.** Pseudo-random bit placement driven by a password-derived seed; hiding arbitrary files; adaptive embedding in textured regions; a steganalysis (chi-square) module; support for audio/video carriers; drag-and-drop and batch operation.

## 13. Viva Questions with Simple Answers

1. **What is steganography?** Hiding the existence of a secret message inside another file, such as an image.
2. **How is it different from cryptography?** Cryptography makes a message unreadable; steganography hides that the message exists. This project uses both.
3. **What does LSB mean?** Least Significant Bit, the right-most bit of a number; changing it alters the value the least.
4. **Why is the change invisible?** Each colour value changes by at most 1 out of 255.
5. **How many bits does one pixel hide here?** Three: one in each of red, green and blue.
6. **How do you calculate capacity?** width x height x 3 bits, divided by 8 for bytes, minus the 14-byte header.
7. **Why save as PNG, not JPEG?** PNG is lossless. JPEG compression changes pixel values and destroys the hidden bits.
8. **How does the decoder know where the message ends?** The header stores the message length, which is validated against the image capacity.
9. **What is the magic identifier?** The bytes `SIS1` at the start of the payload; they tell the decoder the image contains our data.
10. **What is CRC32 used for?** To detect that the hidden data was damaged or modified.
11. **Which encryption is used?** Fernet (AES-128 in CBC mode with HMAC-SHA256 authentication) from the `cryptography` library.
12. **Why not use the password directly as the key?** Passwords are short and guessable. Scrypt stretches it into a strong 32-byte key and is deliberately slow to resist brute force.
13. **What is a salt and why random?** Random extra input to the key derivation so the same password gives a different key each time and precomputed tables do not work. It is stored openly in the payload.
14. **What happens with a wrong password?** Fernet's authentication check fails and the program shows "Incorrect password" instead of garbage text.
15. **What are MSE and PSNR?** MSE is the average squared pixel difference; PSNR = 10 log10(255² / MSE) in dB. Higher PSNR means the images are more similar.
16. **What if MSE is zero?** The images are identical; PSNR would divide by zero, so the program reports infinity.
17. **Is LSB steganography secure?** Not by itself. Statistical analysis can detect it, and image edits destroy it. Encryption protects the content even if the hidden data is found.
18. **Why is the logic separate from the GUI?** So it can be tested automatically, reused, and explained module by module.
19. **How do you handle RGBA images?** Only R, G and B are used; the alpha channel is left unchanged.
20. **How could the project be improved?** Random bit placement, file hiding, adaptive embedding, steganalysis.

## 14. Presentation Outline (9 slides)

1. **Title** — project name, your name, guide, college, date.
2. **Problem and motivation** — encryption reveals that a secret exists; steganography hides it.
3. **Objectives and features** — hide, extract, password protection, quality comparison, GUI.
4. **Technology stack and architecture** — the layered diagram from section 6.
5. **LSB algorithm** — the 180 → 181 example and the payload format.
6. **Encryption** — password → Scrypt + salt → Fernet; encryption vs steganography.
7. **Live demo** — hide with a password, show the PNG, extract it, show a wrong-password error, show the comparison page.
8. **Testing and results** — number of automated tests you ran and passed, your measured MSE/PSNR table, screenshots.
9. **Limitations, future scope and conclusion** — detectability, JPEG fragility, planned improvements; thank you / questions.
