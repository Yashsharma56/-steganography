# Secure Image Steganography Using Python

A desktop application that hides secret text messages inside digital images using
**LSB (Least Significant Bit) steganography**, with optional **password-based
encryption**. Built with Python, Tkinter, Pillow, NumPy, cryptography and Matplotlib
as a BCA-level academic project.

## Problem Statement

Ordinary encryption makes a message unreadable, but it also makes it *obvious* that a
secret exists. Steganography hides the very existence of the message inside a normal
looking carrier such as an image. This project combines both: the message is encrypted
(content protection) and then hidden in an image (concealment).

## Objectives

1. Hide text inside an image with no visible change to the image.
2. Extract the message exactly and detect images that contain no message.
3. Protect the message with a password using modern authenticated encryption.
4. Measure image quality loss with MSE and PSNR.
5. Provide a clean, crash-free GUI suitable for a live demonstration.
6. Keep the code modular, tested and easy to explain.

## Real-Life Applications

- Covert communication where the existence of a message must not be obvious.
- Digital watermarking and copyright marking (the same idea, different payload).
- Educational demonstration of information hiding and cryptography.
- Embedding metadata (author, ID) inside an image file.

## Features

| Feature | Description |
|---|---|
| Hide message | Select image, see dimensions and capacity, type message, save as new PNG |
| Extract message | Read the message back; detects images with no message or corrupted data |
| Password protection | Scrypt key derivation + Fernet authenticated encryption, random salt per message |
| Quality comparison | Side-by-side images, difference map, MSE, PSNR, file sizes, plain-English explanation |
| Safe saving | Original never overwritten; output is always lossless PNG |
| Validation | Empty message, oversize message, bad path, unsupported/fake file, wrong password |

## Technology Stack

| Purpose | Library |
|---|---|
| Language | Python 3.10+ (developed and tested on Python 3.12) |
| GUI | Tkinter + ttk (ships with Python) |
| Images | Pillow |
| Pixel arrays / metrics | NumPy |
| Encryption | `cryptography` (Scrypt + Fernet) |
| Charts | Matplotlib |
| Tests | `unittest` (built in) |

Tested with Pillow 12.1.1, NumPy 2.4.4, cryptography 46.0.6, Matplotlib 3.10.8.

## Installation (Windows + VS Code)

1. Install Python from <https://www.python.org/downloads/>. In the installer tick
   **"Add python.exe to PATH"** and keep **"tcl/tk and IDLE"** ticked (that is Tkinter).
2. Install VS Code and its **Python** extension.
3. In VS Code choose **File > Open Folder** and open `SecureImageSteganography`.
4. Open a terminal (**Terminal > New Terminal**) and run:

```powershell
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

If PowerShell blocks `activate`, run this once and retry:
`Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`

Check the install: `python -c "import tkinter, PIL, numpy, cryptography, matplotlib; print('OK')"`

## Running the Application

```powershell
python main.py
```

Quick demo path: **Hide Message** > browse an image > type a message > tick password >
**Hide & Save** (saved in `output/`) > answer *Yes* to open the comparison > then go to
**Extract Message**, select the saved PNG, enter the password, press **Extract**.

## Running the Tests

```powershell
python -m unittest -v
```

The tests generate their own temporary images; no personal files are needed.

## How the LSB Algorithm Works

Each pixel has three colour values (Red, Green, Blue), each 0-255, stored as 8 bits.
The **least significant bit** is the right-most bit; changing it alters the value by at
most 1, which the eye cannot see.

Hiding one bit in one colour value:

```
value 180      = 1 0 1 1 0 1 0 0
secret bit     = 1
clear LSB      : value & 0b11111110  -> 1 0 1 1 0 1 0 0  (180)
set secret bit : ... | 1             -> 1 0 1 1 0 1 0 1  (181)
```

Hiding the letter `A` (ASCII 65 = `01000001`) in three pixels:

| Pixel | Original (R,G,B) | Bits hidden | New (R,G,B) |
|---|---|---|---|
| 1 | (133, 200, 67) | 0, 1, 0 | (132, 201, 66) |
| 2 | (90, 91, 255) | 0, 0, 0 | (90, 90, 254) |
| 3 | (12, 14, ...) | 0, 1 | (12, 15, ...) |

Capacity = `width x height x 3 / 8` bytes (the alpha channel of RGBA images is left alone).
Extraction reads the same LSBs in the same order.

### Payload format

```
MAGIC "SIS1" (4) | VERSION (1) | FLAGS (1) | LENGTH (4) | CRC32 (4) | BODY (LENGTH bytes)
```

- **MAGIC** tells the decoder the image really contains data from this program.
- **LENGTH** is checked against the image capacity *before* reading, so extraction
  stops at the correct boundary and cannot loop or index out of range.
- **CRC32** detects corruption. **FLAGS** bit 0 marks an encrypted body.

## How Encryption Works

1. A random 16-byte **salt** is generated for every message.
2. **Scrypt** (a deliberately slow, memory-hard function) turns password + salt into a 32-byte key.
3. **Fernet** (AES-128-CBC + HMAC-SHA256) encrypts and *authenticates* the message.
4. The body stored in the image is `salt + Fernet token`. The salt is not secret.
5. On extraction the same steps run in reverse. A wrong password or modified data fails
   authentication and is rejected; it is never decrypted into garbage.

Passwords are never stored, logged or printed.

> **Encryption protects the *contents* of the message. Steganography conceals that a
> message *exists*.** They solve different problems, so this project uses both.

## Project Structure

```
SecureImageSteganography/
├── main.py                    entry point
├── requirements.txt
├── README.md
├── docs/COLLEGE_SUBMISSION.md abstract, diagrams, test cases, viva questions, slides
├── steganography/             all logic, no GUI code
│   ├── errors.py              custom exceptions
│   ├── validators.py          path / message validation
│   ├── payload.py             header format (magic, version, length, CRC)
│   ├── encryption.py          Scrypt + Fernet
│   ├── encoder.py             LSB embedding
│   ├── decoder.py             LSB extraction
│   └── image_metrics.py       MSE, PSNR, file info
├── gui/app.py                 Tkinter interface (calls the package above)
├── tests/                     unittest suites + helpers.py
├── assets/
└── output/                    encoded images are saved here by default
```

## Limitations and Future Enhancements

**Limitations**

- LSB steganography is **not undetectable or unbreakable**. Statistical analysis
  (for example chi-square or RS analysis) can reveal that an image was modified.
- The hidden data is lost if the image is resized, cropped, filtered, screenshotted or
  saved as JPEG. Only lossless PNG/BMP are supported for extraction.
- Only text is supported. Capacity is limited by image size.
- Data is stored in the first pixels in order, which is simple but easier to detect than random placement.
- Security of encrypted messages depends on a strong password.

**Future enhancements**

- Spread bits pseudo-randomly across the image using a password-derived seed.
- Embed arbitrary files, not only text.
- Adaptive embedding in noisy regions; audio/video carriers.
- Steganalysis tool (chi-square test) to demonstrate detection.
- Drag-and-drop and batch processing.

## Troubleshooting

| Problem | Fix |
|---|---|
| `ModuleNotFoundError: No module named 'PIL'` (or numpy etc.) | Activate the venv, then `pip install -r requirements.txt`. In VS Code pick the interpreter: Ctrl+Shift+P > *Python: Select Interpreter* > `venv`. |
| `ModuleNotFoundError: No module named 'tkinter'` | Re-run the Python installer > Modify > tick *tcl/tk and IDLE*. |
| `ModuleNotFoundError: No module named 'steganography'` | Run commands from the project root folder (the one containing `main.py`). |
| "No hidden message found" | The image was resized/re-saved/converted, or was never encoded by this program. |
| Window looks blurry | Already handled in `main.py` for high-DPI screens. |
