"""Image quality metrics: MSE and PSNR, plus file/dimension information.

MSE  = average of (original - encoded)^2 over every pixel value
PSNR = 10 * log10(255^2 / MSE)  decibels (dB); higher means more similar.
If MSE is 0 the images are identical and PSNR is reported as infinity.
"""

import math
import os

import numpy as np
from PIL import Image

from .errors import InvalidImageError
from .validators import validate_image_path

MAX_PIXEL = 255.0


def load_rgb_array(path):
    """Load an image as an RGB uint8 array (alpha is ignored for comparison)."""
    validate_image_path(path)
    try:
        with Image.open(path) as img:
            img.load()
            return np.array(img.convert("RGB"), dtype=np.uint8)
    except (OSError, ValueError) as exc:
        raise InvalidImageError(f"Could not read the image: {exc}") from exc


def calculate_mse(original, encoded):
    """Mean Squared Error between two arrays of identical shape."""
    original = np.asarray(original)
    encoded = np.asarray(encoded)
    if original.shape != encoded.shape:
        raise InvalidImageError(
            f"Images must have the same size to compare: {original.shape[1::-1]} "
            f"vs {encoded.shape[1::-1]}."
        )
    diff = original.astype(np.float64) - encoded.astype(np.float64)  # float avoids uint8 wrap-around
    return float(np.mean(diff ** 2))


def calculate_psnr(mse):
    """PSNR in dB. Returns math.inf when mse == 0 (identical images)."""
    if mse < 0:
        raise ValueError("MSE cannot be negative.")
    if mse == 0:
        return math.inf
    return 10.0 * math.log10((MAX_PIXEL ** 2) / mse)


def interpret_psnr(psnr):
    """Plain-English explanation of a PSNR value."""
    if math.isinf(psnr):
        return "Images are identical - no pixel differences."
    if psnr >= 50:
        return "Excellent: the difference is invisible to the human eye."
    if psnr >= 40:
        return "Very good: differences are practically impossible to see."
    if psnr >= 30:
        return "Acceptable: small differences exist and may be visible on close inspection."
    return "Poor: visible quality loss."


def image_info(path):
    """Width, height, mode and file size in bytes for an image file."""
    validate_image_path(path)
    with Image.open(path) as img:
        width, height = img.size
        mode = img.mode
    return {"width": width, "height": height, "mode": mode,
            "file_size": os.path.getsize(path)}


def compare_images(original_path, encoded_path):
    """Return a dictionary with every value the Comparison page displays."""
    a = load_rgb_array(original_path)
    b = load_rgb_array(encoded_path)
    mse = calculate_mse(a, b)
    psnr = calculate_psnr(mse)
    changed = int(np.count_nonzero(a != b))
    return {
        "original": image_info(original_path),
        "encoded": image_info(encoded_path),
        "mse": mse,
        "psnr": psnr,
        "interpretation": interpret_psnr(psnr),
        "changed_values": changed,
        "total_values": int(a.size),
        "max_difference": int(np.max(np.abs(a.astype(np.int16) - b.astype(np.int16)))),
    }
