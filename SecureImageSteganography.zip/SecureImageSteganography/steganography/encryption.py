"""Password-based authenticated encryption.

Design
------
* Key derivation : Scrypt (memory-hard, resists brute force) with a fresh
                   random 16-byte salt for every message.
* Encryption     : Fernet (AES-128-CBC + HMAC-SHA256). Fernet is *authenticated*:
                   a wrong password or modified data is detected, never silently
                   decrypted into garbage.
* Stored blob    : salt (16 bytes) + Fernet token. The salt is not secret.

Passwords are never stored or printed anywhere.
"""

import base64
import os

from cryptography.exceptions import InvalidKey
from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

from .errors import CorruptedDataError, InvalidMessageError, WrongPasswordError

SALT_SIZE = 16
SCRYPT_N = 2 ** 14  # CPU/memory cost (about 16 MB, ~0.1 s) - fine for a desktop app
SCRYPT_R = 8
SCRYPT_P = 1


def derive_key(password, salt):
    """Turn a password + salt into a 32-byte key in the format Fernet expects."""
    kdf = Scrypt(salt=salt, length=32, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P)
    raw_key = kdf.derive(password.encode("utf-8"))
    return base64.urlsafe_b64encode(raw_key)


def encrypt_message(message, password):
    """Encrypt text with a password. Returns bytes: salt + Fernet token."""
    if not password:
        raise InvalidMessageError("Password cannot be empty.")
    salt = os.urandom(SALT_SIZE)
    token = Fernet(derive_key(password, salt)).encrypt(message.encode("utf-8"))
    return salt + token


def decrypt_message(blob, password):
    """Reverse of encrypt_message. Raises WrongPasswordError on failure."""
    if not password:
        raise InvalidMessageError("Password cannot be empty.")
    if len(blob) <= SALT_SIZE:
        raise CorruptedDataError("Encrypted data is too short to be valid.")
    salt, token = blob[:SALT_SIZE], blob[SALT_SIZE:]
    try:
        plain = Fernet(derive_key(password, salt)).decrypt(token)
    except (InvalidToken, InvalidKey, ValueError) as exc:
        raise WrongPasswordError(
            "Incorrect password, or the hidden data has been modified."
        ) from exc
    try:
        return plain.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise CorruptedDataError("Decrypted data is not valid text.") from exc
