"""Custom exceptions so the GUI can show friendly messages for each failure."""


class SteganographyError(Exception):
    """Base class for every error raised by this project."""


class InvalidImageError(SteganographyError):
    """The image path is wrong, the file is missing, or the format is unsupported."""


class InvalidMessageError(SteganographyError):
    """The secret message or password is not acceptable (for example, empty)."""


class CapacityError(SteganographyError):
    """The message is too large to fit inside the chosen image."""


class NoHiddenMessageError(SteganographyError):
    """The image does not contain a message created by this program."""


class CorruptedDataError(SteganographyError):
    """A hidden message was found, but its data is damaged or inconsistent."""


class PasswordRequiredError(SteganographyError):
    """The hidden message is encrypted but no password was supplied."""


class WrongPasswordError(SteganographyError):
    """The password is wrong (or the encrypted data was modified)."""
