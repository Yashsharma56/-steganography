"""Payload format: what exactly gets hidden inside the image.

Layout (big-endian), 14-byte header followed by the body:

    offset  size  field
    0       4     MAGIC      b"SIS1"  -> "this image contains our data"
    4       1     VERSION    1
    5       1     FLAGS      bit 0 = body is encrypted
    6       4     LENGTH     number of body bytes
    10      4     CRC32      checksum of the body (detects corruption)
    14      n     BODY       UTF-8 text, or salt + Fernet token if encrypted

The explicit LENGTH means extraction knows exactly where the message ends,
so no end-of-message marker is needed and no infinite loop is possible.
"""

import struct
import zlib

from .errors import CorruptedDataError, NoHiddenMessageError

MAGIC = b"SIS1"
VERSION = 1
FLAG_ENCRYPTED = 0x01
HEADER_FORMAT = ">4sBBII"
HEADER_SIZE = struct.calcsize(HEADER_FORMAT)  # 14 bytes


def build_payload(body, encrypted):
    """Wrap `body` bytes with the header."""
    flags = FLAG_ENCRYPTED if encrypted else 0
    header = struct.pack(HEADER_FORMAT, MAGIC, VERSION, flags, len(body),
                         zlib.crc32(body) & 0xFFFFFFFF)
    return header + body


def parse_header(header_bytes):
    """Validate the header and return (is_encrypted, body_length, crc32)."""
    if len(header_bytes) < HEADER_SIZE:
        raise NoHiddenMessageError("The image is too small to contain a message.")
    magic, version, flags, length, crc = struct.unpack(
        HEADER_FORMAT, header_bytes[:HEADER_SIZE])
    if magic != MAGIC:
        raise NoHiddenMessageError(
            "No hidden message found. This image was not created by this program, "
            "or it was edited/compressed after encoding."
        )
    if version != VERSION:
        raise CorruptedDataError(f"Unsupported payload version: {version}.")
    return bool(flags & FLAG_ENCRYPTED), length, crc


def verify_body(body, expected_crc):
    """Raise if the body does not match the stored checksum."""
    if (zlib.crc32(body) & 0xFFFFFFFF) != expected_crc:
        raise CorruptedDataError(
            "The hidden data is corrupted (checksum mismatch). "
            "The image may have been modified after encoding."
        )
