"""LSB encoder: hides a text message inside an image.

How it works (one pixel channel, 8 bits):
    original value  : 1 0 1 1 0 1 0 0   (180)
    secret bit      : 1
    clear the LSB   : 1 0 1 1 0 1 0 0   (value & 0b11111110)
    set secret bit  : 1 0 1 1 0 1 0 1   (181)   -> change of at most 1 out of 255

Each pixel has 3 colour channels (R, G, B), so each pixel hides 3 bits.
The alpha (transparency) channel of RGBA images is left untouched.
"""

import os

import numpy as np
from PIL import Image

from . import payload as payload_format
from .encryption import SALT_SIZE, encrypt_message
from .errors import CapacityError, InvalidImageError
from .validators import (validate_image_path, validate_message,
                         validate_output_path)

BITS_PER_PIXEL = 3  # one LSB in each of R, G, B


def load_image_array(path):
    """Open an image and return a uint8 numpy array of shape (H, W, 3) or (H, W, 4).

    Palette, grayscale, CMYK etc. are converted to RGB. RGBA keeps its alpha.
    """
    validate_image_path(path)
    try:
        with Image.open(path) as img:
            img.load()
            mode = "RGBA" if img.mode in ("RGBA", "LA", "PA") or \
                ("transparency" in img.info) else "RGB"
            return np.array(img.convert(mode), dtype=np.uint8)
    except (OSError, ValueError) as exc:
        raise InvalidImageError(f"Could not read the image: {exc}") from exc


def calculate_capacity_bytes(width, height):
    """How many bytes (header included) can be hidden in an image of this size."""
    return (width * height * BITS_PER_PIXEL) // 8


def estimate_payload_size(message_byte_count, encrypted):
    """Exact number of bytes that will be hidden for a message of this size.

    Plain   : header + message bytes.
    Encrypted: header + salt(16) + Fernet token, where the token is base64 of
               [version 1 + timestamp 8 + IV 16 + AES-CBC ciphertext + HMAC 32].
               AES-CBC pads the message up to the next multiple of 16 bytes.
    """
    if not encrypted:
        return payload_format.HEADER_SIZE + message_byte_count
    padded = 16 * (message_byte_count // 16 + 1)
    raw_token = 1 + 8 + 16 + padded + 32
    token_len = 4 * ((raw_token + 2) // 3)  # base64 with padding
    return payload_format.HEADER_SIZE + SALT_SIZE + token_len


def embed_bytes(pixels, data):
    """Write `data` into the LSBs of `pixels` (returns a new array)."""
    bits = np.unpackbits(np.frombuffer(data, dtype=np.uint8))
    capacity_bits = pixels.shape[0] * pixels.shape[1] * BITS_PER_PIXEL
    if bits.size > capacity_bits:
        raise CapacityError(
            f"Message needs {bits.size} bits but the image holds only {capacity_bits}."
        )
    result = pixels.copy()
    rgb = result[..., :3].reshape(-1)          # copy of the colour channels, flattened
    rgb[:bits.size] = (rgb[:bits.size] & 0xFE) | bits   # clear LSB, then set secret bit
    result[..., :3] = rgb.reshape(result[..., :3].shape)
    return result


def embed_message(pixels, message, password=None):
    """Build the payload (optionally encrypted) and embed it. Returns new pixel array."""
    validate_message(message)
    if password:
        body = encrypt_message(message, password)
        data = payload_format.build_payload(body, encrypted=True)
    else:
        body = message.encode("utf-8")
        data = payload_format.build_payload(body, encrypted=False)
    capacity = calculate_capacity_bytes(pixels.shape[1], pixels.shape[0])
    if len(data) > capacity:
        raise CapacityError(
            f"The message is too large for this image: it needs {len(data)} bytes "
            f"but the image can hold {capacity} bytes. "
            "Use a larger image or a shorter message."
        )
    return embed_bytes(pixels, data)


def encode_image(input_path, output_path, message, password=None):
    """High-level helper used by the GUI: read image, hide message, save PNG.

    The original file is never modified. Refuses to overwrite the input file.
    """
    validate_output_path(output_path)
    if os.path.abspath(input_path) == os.path.abspath(output_path):
        raise InvalidImageError("The output file must be different from the original image.")
    pixels = load_image_array(input_path)
    stego = embed_message(pixels, message, password)
    mode = "RGBA" if stego.shape[2] == 4 else "RGB"
    try:
        Image.fromarray(stego, mode).save(output_path, format="PNG")
    except OSError as exc:
        raise InvalidImageError(f"Could not save the image: {exc}") from exc
    return output_path
