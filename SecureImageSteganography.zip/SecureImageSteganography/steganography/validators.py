"""Input validation helpers shared by the encoder, decoder and GUI."""

import os

from PIL import Image, UnidentifiedImageError

from .errors import InvalidImageError, InvalidMessageError

# Formats we accept as a *cover* image (the image we hide data in).
COVER_EXTENSIONS = (".png", ".bmp", ".jpg", ".jpeg")
# Formats we accept for *extraction*. JPEG is excluded on purpose: it is lossy,
# so any hidden data it once held would have been destroyed by compression.
STEGO_EXTENSIONS = (".png", ".bmp")


def validate_image_path(path, allowed_extensions=COVER_EXTENSIONS):
    """Check that `path` is an existing, supported, readable image file."""
    if not path or not str(path).strip():
        raise InvalidImageError("No image selected. Please choose an image file.")
    if not os.path.isfile(path):
        raise InvalidImageError(f"File not found: {path}")
    ext = os.path.splitext(path)[1].lower()
    if ext not in allowed_extensions:
        if ext in (".jpg", ".jpeg") and allowed_extensions == STEGO_EXTENSIONS:
            raise InvalidImageError(
                "JPEG files cannot hold hidden data reliably (lossy compression). "
                "Please select the lossless PNG file that was saved by this program."
            )
        raise InvalidImageError(
            f"Unsupported file type '{ext or 'none'}'. "
            f"Supported: {', '.join(allowed_extensions)}"
        )
    try:
        with Image.open(path) as img:
            img.verify()  # detects truncated / fake image files
    except (UnidentifiedImageError, OSError, SyntaxError) as exc:
        raise InvalidImageError(f"The file is not a valid image: {exc}") from exc


def validate_output_path(path):
    """The encoded image must be saved as PNG (lossless)."""
    if not path or not str(path).strip():
        raise InvalidImageError("No output file chosen.")
    if os.path.splitext(path)[1].lower() != ".png":
        raise InvalidImageError(
            "Encoded images must be saved as .png (lossless). "
            "JPEG would destroy the hidden data."
        )
    folder = os.path.dirname(os.path.abspath(path))
    if not os.path.isdir(folder):
        raise InvalidImageError(f"Output folder does not exist: {folder}")


def validate_message(message):
    """A secret message must be non-empty text."""
    if not isinstance(message, str):
        raise InvalidMessageError("The message must be text.")
    if message.strip() == "":
        raise InvalidMessageError("The secret message is empty. Please type something.")


def default_output_path(input_path, output_dir):
    """Build a safe output name like 'photo_encoded.png' that never equals the input."""
    base = os.path.splitext(os.path.basename(input_path))[0]
    candidate = os.path.join(output_dir, f"{base}_encoded.png")
    counter = 1
    while os.path.exists(candidate):  # never overwrite an existing file
        candidate = os.path.join(output_dir, f"{base}_encoded_{counter}.png")
        counter += 1
    return candidate
