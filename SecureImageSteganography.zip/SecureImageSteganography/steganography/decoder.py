"""LSB decoder: reads a hidden message back out of an image."""

import numpy as np
from PIL import Image

from . import payload as payload_format
from .encoder import BITS_PER_PIXEL
from .encryption import decrypt_message
from .errors import (CorruptedDataError, InvalidImageError,
                     NoHiddenMessageError, PasswordRequiredError)
from .validators import STEGO_EXTENSIONS, validate_image_path


def load_stego_array(path):
    """Load an encoded image as a numpy array (same colour handling as the encoder)."""
    validate_image_path(path, STEGO_EXTENSIONS)
    try:
        with Image.open(path) as img:
            img.load()
            mode = "RGBA" if img.mode in ("RGBA", "LA", "PA") or \
                ("transparency" in img.info) else "RGB"
            return np.array(img.convert(mode), dtype=np.uint8)
    except (OSError, ValueError) as exc:
        raise InvalidImageError(f"Could not read the image: {exc}") from exc


def read_bytes(pixels, start_byte, count):
    """Read `count` bytes from the LSB stream beginning at byte offset `start_byte`.

    Raises NoHiddenMessageError / CorruptedDataError if the range leaves the image.
    """
    channels = pixels[..., :3].reshape(-1)
    start_bit, end_bit = start_byte * 8, (start_byte + count) * 8
    if end_bit > channels.size:
        raise CorruptedDataError(
            "The stored message length is larger than the image can hold."
        )
    bits = channels[start_bit:end_bit] & 1
    return np.packbits(bits).tobytes()


def extract_message(pixels, password=None):
    """Extract (and decrypt if needed) the hidden text from a pixel array."""
    total_bytes = (pixels.shape[0] * pixels.shape[1] * BITS_PER_PIXEL) // 8
    if total_bytes < payload_format.HEADER_SIZE:
        raise NoHiddenMessageError("The image is too small to contain a message.")

    header = read_bytes(pixels, 0, payload_format.HEADER_SIZE)
    encrypted, length, crc = payload_format.parse_header(header)

    # Validate the declared length BEFORE reading, so a bogus header cannot
    # cause out-of-range reads or huge allocations.
    if length > total_bytes - payload_format.HEADER_SIZE:
        raise CorruptedDataError(
            "The stored message length is larger than the image can hold."
        )
    body = read_bytes(pixels, payload_format.HEADER_SIZE, length)
    payload_format.verify_body(body, crc)

    if encrypted:
        if not password:
            raise PasswordRequiredError(
                "This message is password-protected. Please enter the password."
            )
        return decrypt_message(body, password)
    try:
        return body.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise CorruptedDataError("The hidden data is not valid text.") from exc


def is_encrypted(pixels):
    """Peek at the header to tell the GUI whether a password is needed."""
    header = read_bytes(pixels, 0, payload_format.HEADER_SIZE)
    return payload_format.parse_header(header)[0]


def decode_image(path, password=None):
    """High-level helper used by the GUI."""
    return extract_message(load_stego_array(path), password)
