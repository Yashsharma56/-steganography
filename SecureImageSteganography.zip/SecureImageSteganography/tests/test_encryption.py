import unittest

from steganography.encryption import (SALT_SIZE, decrypt_message, derive_key,
                                      encrypt_message)
from steganography.errors import (CorruptedDataError, InvalidMessageError,
                                  WrongPasswordError)


class EncryptionTests(unittest.TestCase):
    def test_round_trip(self):
        blob = encrypt_message("hello", "pass123")
        self.assertEqual(decrypt_message(blob, "pass123"), "hello")

    def test_unicode_round_trip(self):
        text = "नमस्ते 🔐"
        self.assertEqual(decrypt_message(encrypt_message(text, "p"), "p"), text)

    def test_wrong_password(self):
        blob = encrypt_message("hello", "right")
        with self.assertRaises(WrongPasswordError):
            decrypt_message(blob, "wrong")

    def test_unique_salt_each_time(self):
        a = encrypt_message("same", "same")
        b = encrypt_message("same", "same")
        self.assertNotEqual(a[:SALT_SIZE], b[:SALT_SIZE])
        self.assertNotEqual(a, b)

    def test_plaintext_not_in_ciphertext(self):
        self.assertNotIn(b"plainsecret", encrypt_message("plainsecret", "pw"))

    def test_modified_ciphertext_rejected(self):
        blob = bytearray(encrypt_message("hello", "pw"))
        blob[SALT_SIZE + 20] ^= 0x01
        with self.assertRaises(WrongPasswordError):
            decrypt_message(bytes(blob), "pw")

    def test_modified_salt_rejected(self):
        blob = bytearray(encrypt_message("hello", "pw"))
        blob[0] ^= 0x01
        with self.assertRaises(WrongPasswordError):
            decrypt_message(bytes(blob), "pw")

    def test_too_short_blob(self):
        with self.assertRaises(CorruptedDataError):
            decrypt_message(b"short", "pw")

    def test_empty_password_rejected(self):
        with self.assertRaises(InvalidMessageError):
            encrypt_message("hello", "")
        with self.assertRaises(InvalidMessageError):
            decrypt_message(b"x" * 50, "")

    def test_key_derivation_is_deterministic_for_same_salt(self):
        salt = b"0" * SALT_SIZE
        self.assertEqual(derive_key("pw", salt), derive_key("pw", salt))
        self.assertNotEqual(derive_key("pw", salt), derive_key("pw2", salt))


if __name__ == "__main__":
    unittest.main()
