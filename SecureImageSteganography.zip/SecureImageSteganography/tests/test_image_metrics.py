import math
import os
import tempfile
import unittest

import numpy as np

from steganography.encoder import encode_image
from steganography.errors import InvalidImageError
from steganography.image_metrics import (calculate_mse, calculate_psnr,
                                         compare_images, interpret_psnr)
from tests.helpers import make_test_image


class MetricsTests(unittest.TestCase):
    def test_identical_arrays_zero_mse_infinite_psnr(self):
        a = np.full((10, 10, 3), 100, dtype=np.uint8)
        mse = calculate_mse(a, a.copy())
        self.assertEqual(mse, 0.0)
        self.assertTrue(math.isinf(calculate_psnr(mse)))  # no division error

    def test_known_mse_value(self):
        a = np.zeros((2, 2, 3), dtype=np.uint8)
        b = np.full((2, 2, 3), 2, dtype=np.uint8)
        self.assertAlmostEqual(calculate_mse(a, b), 4.0)

    def test_uint8_no_wraparound(self):
        a = np.zeros((1, 1, 3), dtype=np.uint8)
        b = np.full((1, 1, 3), 255, dtype=np.uint8)
        self.assertAlmostEqual(calculate_mse(a, b), 255.0 ** 2)

    def test_known_psnr_value(self):
        self.assertAlmostEqual(calculate_psnr(1.0), 10 * math.log10(255 ** 2), places=6)
        self.assertAlmostEqual(calculate_psnr(1.0), 48.1308, places=3)

    def test_negative_mse_rejected(self):
        with self.assertRaises(ValueError):
            calculate_psnr(-1)

    def test_size_mismatch(self):
        with self.assertRaises(InvalidImageError):
            calculate_mse(np.zeros((2, 2, 3)), np.zeros((3, 3, 3)))

    def test_interpretation_text(self):
        self.assertIn("identical", interpret_psnr(math.inf))
        self.assertIn("Excellent", interpret_psnr(60))
        self.assertIn("Poor", interpret_psnr(10))

    def test_compare_images_after_encoding(self):
        with tempfile.TemporaryDirectory() as d:
            cover = make_test_image(os.path.join(d, "c.png"), 64, 64)
            out = os.path.join(d, "o.png")
            encode_image(cover, out, "hello metrics")
            r = compare_images(cover, out)
            self.assertEqual(r["original"]["width"], 64)
            self.assertLessEqual(r["max_difference"], 1)
            self.assertGreater(r["psnr"], 50)
            self.assertGreater(r["encoded"]["file_size"], 0)

    def test_compare_identical_files(self):
        with tempfile.TemporaryDirectory() as d:
            cover = make_test_image(os.path.join(d, "c.png"))
            r = compare_images(cover, cover)
            self.assertEqual(r["mse"], 0.0)
            self.assertTrue(math.isinf(r["psnr"]))


if __name__ == "__main__":
    unittest.main()
