import os
import tempfile
import unittest

import numpy as np
from PIL import Image

from steganography import payload
from steganography.decoder import decode_image, extract_message, is_encrypted, load_stego_array
from steganography.encoder import (calculate_capacity_bytes, embed_message,
                                   encode_image, load_image_array)
from steganography.errors import (CapacityError, CorruptedDataError, InvalidImageError,
                                  InvalidMessageError, NoHiddenMessageError,
                                  PasswordRequiredError, WrongPasswordError)
from tests.helpers import make_test_image


class EncoderDecoderTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = self.tmp.name
        self.cover = make_test_image(os.path.join(self.dir, "cover.png"))
        self.out = os.path.join(self.dir, "stego.png")

    def tearDown(self):
        self.tmp.cleanup()

    # ---- normal use -------------------------------------------------------
    def test_hide_and_extract_normal_message(self):
        encode_image(self.cover, self.out, "Hello, World!")
        self.assertEqual(decode_image(self.out), "Hello, World!")

    def test_unicode_message(self):
        text = "नमस्ते 你好 مرحبا 🔐✨"
        encode_image(self.cover, self.out, text)
        self.assertEqual(decode_image(self.out), text)

    def test_multiline_message(self):
        text = "line1\nline2\n\tindented"
        encode_image(self.cover, self.out, text)
        self.assertEqual(decode_image(self.out), text)

    def test_original_image_is_not_modified(self):
        with open(self.cover, "rb") as f:
            before = f.read()
        encode_image(self.cover, self.out, "secret")
        with open(self.cover, "rb") as f:
            self.assertEqual(before, f.read())

    def test_refuses_to_overwrite_original(self):
        with self.assertRaises(InvalidImageError):
            encode_image(self.cover, self.cover, "secret")

    def test_pixels_change_by_at_most_one(self):
        encode_image(self.cover, self.out, "A fairly long secret message " * 5)
        a = load_image_array(self.cover).astype(int)
        b = load_image_array(self.out).astype(int)
        self.assertLessEqual(int(np.abs(a - b).max()), 1)

    def test_rgba_image_keeps_alpha(self):
        rgba = make_test_image(os.path.join(self.dir, "rgba.png"), mode="RGBA")
        encode_image(rgba, self.out, "alpha test")
        self.assertEqual(decode_image(self.out), "alpha test")
        with Image.open(rgba) as ia, Image.open(self.out) as ib:
            a = np.array(ia)[..., 3]
            b = np.array(ib)[..., 3]
        self.assertTrue(np.array_equal(a, b))

    def test_palette_and_grayscale_images(self):
        for mode in ("L", "P"):
            path = os.path.join(self.dir, f"{mode}.png")
            Image.new(mode, (40, 40)).save(path)
            out = os.path.join(self.dir, f"{mode}_out.png")
            encode_image(path, out, "converted")
            self.assertEqual(decode_image(out), "converted")

    # ---- capacity ---------------------------------------------------------
    def test_size_estimate_matches_real_payload(self):
        from steganography.decoder import read_bytes
        from steganography.encoder import estimate_payload_size
        for text in ("a", "a" * 15, "a" * 16, "a" * 100, "नमस्ते" * 7):
            n = len(text.encode("utf-8"))
            self.assertEqual(estimate_payload_size(n, False), payload.HEADER_SIZE + n)
            pixels = embed_message(load_image_array(self.cover), text, "pw")
            hdr = read_bytes(pixels, 0, payload.HEADER_SIZE)
            _, body_len, _ = payload.parse_header(hdr)
            self.assertEqual(estimate_payload_size(n, True), payload.HEADER_SIZE + body_len)

    def test_message_exactly_at_capacity(self):
        small = make_test_image(os.path.join(self.dir, "small.png"), 16, 16)
        max_len = calculate_capacity_bytes(16, 16) - payload.HEADER_SIZE
        text = "a" * max_len
        encode_image(small, self.out, text)
        self.assertEqual(decode_image(self.out), text)

    def test_message_over_capacity_rejected(self):
        small = make_test_image(os.path.join(self.dir, "small.png"), 16, 16)
        max_len = calculate_capacity_bytes(16, 16) - payload.HEADER_SIZE
        with self.assertRaises(CapacityError):
            encode_image(small, self.out, "a" * (max_len + 1))
        self.assertFalse(os.path.exists(self.out))  # nothing saved on failure

    # ---- empty / invalid input -------------------------------------------
    def test_empty_message_rejected(self):
        for bad in ("", "   ", "\n"):
            with self.assertRaises(InvalidMessageError):
                encode_image(self.cover, self.out, bad)

    def test_invalid_paths(self):
        with self.assertRaises(InvalidImageError):
            encode_image(os.path.join(self.dir, "missing.png"), self.out, "x")
        with self.assertRaises(InvalidImageError):
            encode_image("", self.out, "x")
        with self.assertRaises(InvalidImageError):
            decode_image(os.path.join(self.dir, "missing.png"))
        with self.assertRaises(InvalidImageError):  # folder does not exist
            encode_image(self.cover, os.path.join(self.dir, "nope", "o.png"), "x")

    def test_unsupported_formats(self):
        txt = os.path.join(self.dir, "note.txt")
        with open(txt, "w") as f:
            f.write("not an image")
        with self.assertRaises(InvalidImageError):
            encode_image(txt, self.out, "x")
        fake = os.path.join(self.dir, "fake.png")  # right extension, wrong content
        with open(fake, "w") as f:
            f.write("not an image")
        with self.assertRaises(InvalidImageError):
            encode_image(fake, self.out, "x")
        with self.assertRaises(InvalidImageError):  # output must be PNG
            encode_image(self.cover, os.path.join(self.dir, "out.jpg"), "x")

    def test_jpeg_rejected_for_extraction(self):
        jpg = os.path.join(self.dir, "photo.jpg")
        Image.new("RGB", (32, 32)).save(jpg)
        with self.assertRaises(InvalidImageError) as ctx:
            decode_image(jpg)
        self.assertIn("JPEG", str(ctx.exception))

    def test_jpeg_cover_accepted_and_saved_as_png(self):
        jpg = os.path.join(self.dir, "cover.jpg")
        Image.new("RGB", (64, 64), (120, 130, 140)).save(jpg)
        encode_image(jpg, self.out, "from jpeg")
        self.assertEqual(decode_image(self.out), "from jpeg")

    # ---- extraction of images without data / corrupted data ---------------
    def test_image_without_message(self):
        with self.assertRaises(NoHiddenMessageError):
            decode_image(self.cover)

    def test_all_zero_image_without_message(self):
        blank = os.path.join(self.dir, "blank.png")
        Image.new("RGB", (50, 50), (0, 0, 0)).save(blank)
        with self.assertRaises(NoHiddenMessageError):
            decode_image(blank)

    def test_tiny_image_without_message(self):
        tiny = os.path.join(self.dir, "tiny.png")
        Image.new("RGB", (2, 2)).save(tiny)  # 12 bits < header size
        with self.assertRaises(NoHiddenMessageError):
            decode_image(tiny)

    def test_corrupted_body_detected(self):
        encode_image(self.cover, self.out, "important message")
        pixels = load_stego_array(self.out)
        flat = pixels[..., :3].reshape(-1)
        flat[payload.HEADER_SIZE * 8 + 3] ^= 1   # flip one bit inside the body
        pixels[..., :3] = flat.reshape(pixels[..., :3].shape)
        with self.assertRaises(CorruptedDataError):
            extract_message(pixels)

    def test_bogus_length_in_header_detected(self):
        """A header claiming a huge length must not cause out-of-range reads."""
        header = payload.build_payload(b"x", False)
        bad = bytearray(header)
        bad[6:10] = (10 ** 9).to_bytes(4, "big")
        from steganography.encoder import embed_bytes
        pixels = embed_bytes(load_image_array(self.cover), bytes(bad))
        with self.assertRaises(CorruptedDataError):
            extract_message(pixels)

    def test_saved_png_can_be_reopened_and_decoded(self):
        encode_image(self.cover, self.out, "round trip")
        with Image.open(self.out) as img:
            self.assertEqual(img.format, "PNG")
        self.assertEqual(decode_image(self.out), "round trip")

    # ---- passwords --------------------------------------------------------
    def test_correct_password(self):
        encode_image(self.cover, self.out, "top secret", password="S3cret!")
        self.assertTrue(is_encrypted(load_stego_array(self.out)))
        self.assertEqual(decode_image(self.out, "S3cret!"), "top secret")

    def test_wrong_password_rejected(self):
        encode_image(self.cover, self.out, "top secret", password="right")
        with self.assertRaises(WrongPasswordError):
            decode_image(self.out, "wrong")

    def test_missing_password_reported(self):
        encode_image(self.cover, self.out, "top secret", password="right")
        with self.assertRaises(PasswordRequiredError):
            decode_image(self.out)

    def test_message_text_not_visible_in_encrypted_payload(self):
        pixels = embed_message(load_image_array(self.cover), "findme-plaintext", "pw")
        from steganography.decoder import read_bytes
        raw = read_bytes(pixels, 0, 100)
        self.assertNotIn(b"findme-plaintext", raw)

    def test_tampered_encrypted_body_rejected(self):
        """Even with a valid checksum, Fernet's authentication must catch tampering."""
        from steganography.encoder import embed_bytes
        from steganography.encryption import encrypt_message
        blob = bytearray(encrypt_message("secret", "pw"))
        blob[-5] ^= 0xFF
        data = payload.build_payload(bytes(blob), encrypted=True)
        pixels = embed_bytes(load_image_array(self.cover), data)
        with self.assertRaises(WrongPasswordError):
            extract_message(pixels, "pw")


if __name__ == "__main__":
    unittest.main()
