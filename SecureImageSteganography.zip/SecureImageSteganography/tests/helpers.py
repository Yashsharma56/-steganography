"""Shared helpers: tests generate their own images, no personal files needed."""

import numpy as np
from PIL import Image


def make_test_image(path, width=64, height=64, mode="RGB", seed=0):
    """Create a reproducible random image and save it to `path`."""
    rng = np.random.default_rng(seed)
    channels = 4 if mode == "RGBA" else 3
    data = rng.integers(0, 256, (height, width, channels), dtype=np.uint8)
    Image.fromarray(data, mode).save(path)
    return path
