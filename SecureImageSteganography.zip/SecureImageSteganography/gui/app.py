"""Tkinter GUI. Contains NO steganography logic - it only calls the
`steganography` package and shows results / error messages."""

import math
import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import numpy as np
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from PIL import Image, ImageTk

from steganography import payload as payload_format
from steganography.decoder import decode_image, is_encrypted, load_stego_array
from steganography.encoder import (calculate_capacity_bytes, encode_image,
                                   estimate_payload_size)
from steganography.errors import (PasswordRequiredError, SteganographyError,
                                  WrongPasswordError)
from steganography.image_metrics import compare_images, load_rgb_array
from steganography.validators import default_output_path, validate_image_path, validate_message
from steganography.validators import STEGO_EXTENSIONS

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTPUT_DIR = os.path.join(BASE_DIR, "output")

# ---- colour scheme ---------------------------------------------------------
NAVY = "#1F3A5F"
BLUE = "#2E75B6"
BG = "#F3F5F9"
WHITE = "#FFFFFF"
TEXT = "#1B2430"
MUTED = "#5F6B7A"
OK_GREEN = "#1E8449"
ERR_RED = "#C0392B"

FONT = "Segoe UI"
IMAGE_TYPES = [("Images", "*.png *.bmp *.jpg *.jpeg"), ("All files", "*.*")]
STEGO_TYPES = [("Encoded images (PNG/BMP)", "*.png *.bmp"), ("All files", "*.*")]


def configure_styles(root):
    style = ttk.Style(root)
    style.theme_use("clam")
    root.configure(bg=BG)
    style.configure(".", background=BG, foreground=TEXT, font=(FONT, 10))
    style.configure("TFrame", background=BG)
    style.configure("Card.TFrame", background=WHITE)
    style.configure("TLabelframe", background=BG, bordercolor="#C9D1DC")
    style.configure("TLabelframe.Label", background=BG, foreground=NAVY,
                    font=(FONT, 10, "bold"))
    style.configure("Title.TLabel", font=(FONT, 18, "bold"), foreground=NAVY, background=BG)
    style.configure("Sub.TLabel", foreground=MUTED, background=BG)
    style.configure("Info.TLabel", foreground=MUTED, background=BG, font=(FONT, 9))
    style.configure("Card.TLabel", background=WHITE)
    style.configure("CardTitle.TLabel", background=WHITE, foreground=NAVY,
                    font=(FONT, 12, "bold"))
    style.configure("TCheckbutton", background=BG)
    style.configure("TButton", padding=(10, 6), background="#DDE3EC", borderwidth=0)
    style.map("TButton", background=[("active", "#C9D3E0")])
    style.configure("Accent.TButton", background=BLUE, foreground=WHITE,
                    font=(FONT, 10, "bold"))
    style.map("Accent.TButton", background=[("active", NAVY), ("disabled", "#9BB5D3")])
    style.configure("Nav.TButton", background=NAVY, foreground=WHITE, padding=(16, 12),
                    anchor="w", font=(FONT, 11))
    style.map("Nav.TButton", background=[("active", BLUE)])
    style.configure("NavActive.TButton", background=BLUE, foreground=WHITE,
                    padding=(16, 12), anchor="w", font=(FONT, 11, "bold"))
    style.configure("Treeview", rowheight=24, font=(FONT, 10))
    style.configure("Treeview.Heading", font=(FONT, 10, "bold"))


def format_size(num_bytes):
    if num_bytes < 1024:
        return f"{num_bytes} B"
    if num_bytes < 1024 ** 2:
        return f"{num_bytes / 1024:.1f} KB"
    return f"{num_bytes / 1024 ** 2:.2f} MB"


class ImagePreview(tk.Frame):
    """Fixed-size box that shows a thumbnail of an image (or a placeholder text)."""

    def __init__(self, parent, width=380, height=250, placeholder="No image selected"):
        super().__init__(parent, width=width, height=height, bg="#E4E9F0",
                         highlightbackground="#C9D1DC", highlightthickness=1)
        self.pack_propagate(False)
        self.width, self.height, self.placeholder = width - 4, height - 4, placeholder
        self._photo = None  # keep a reference or Tk will garbage-collect the image
        self.label = tk.Label(self, text=placeholder, bg="#E4E9F0", fg=MUTED,
                              font=(FONT, 10))
        self.label.pack(fill="both", expand=True)

    def show(self, path):
        with Image.open(path) as img:
            img.thumbnail((self.width, self.height))
            thumb = img.convert("RGB")
        self._photo = ImageTk.PhotoImage(thumb)
        self.label.configure(image=self._photo, text="")

    def clear(self):
        self._photo = None
        self.label.configure(image="", text=self.placeholder)


class Page(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, padding=20)
        self.app = app


# =============================================================================
# Home
# =============================================================================
class HomePage(Page):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        ttk.Label(self, text="Secure Image Steganography", style="Title.TLabel").pack(anchor="w")
        ttk.Label(self, style="Sub.TLabel", wraplength=760, justify="left",
                  text="Hide secret text inside an image using LSB steganography, "
                       "optionally protected by a password.").pack(anchor="w", pady=(2, 18))

        grid = ttk.Frame(self)
        grid.pack(fill="x")
        cards = [
            ("Hide Message", "Embed a text message into an image and save it as PNG.", "hide"),
            ("Extract Message", "Read a hidden message back out of an encoded image.", "extract"),
            ("Compare Images", "See MSE, PSNR and a difference map of original vs encoded.", "compare"),
            ("About Project", "How it works, technologies used and limitations.", "about"),
        ]
        for i, (title, desc, page) in enumerate(cards):
            card = ttk.Frame(grid, style="Card.TFrame", padding=16)
            card.grid(row=i // 2, column=i % 2, padx=8, pady=8, sticky="nsew")
            ttk.Label(card, text=title, style="CardTitle.TLabel").pack(anchor="w")
            ttk.Label(card, text=desc, style="Card.TLabel", wraplength=320,
                      justify="left").pack(anchor="w", pady=(4, 10))
            ttk.Button(card, text="Open", style="Accent.TButton",
                       command=lambda p=page: app.show_page(p)).pack(anchor="w")
        grid.columnconfigure(0, weight=1)
        grid.columnconfigure(1, weight=1)

        note = ttk.LabelFrame(self, text="Good to know", padding=12)
        note.pack(fill="x", pady=(14, 0), padx=8)
        ttk.Label(note, justify="left", wraplength=740, text=(
            "- Encryption protects the CONTENT of the message; steganography only "
            "CONCEALS that a message exists. This tool uses both.\n"
            "- Encoded images are always saved as PNG (lossless). Never convert them "
            "to JPEG or re-save/resize them - the hidden data would be destroyed.\n"
            "- LSB steganography is not undetectable or unbreakable; statistical "
            "analysis can reveal it.")).pack(anchor="w")


# =============================================================================
# Hide
# =============================================================================
class HidePage(Page):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        self.image_path = None
        self.capacity_bytes = 0

        ttk.Label(self, text="Hide a Secret Message", style="Title.TLabel").grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))

        left = ttk.LabelFrame(self, text="1. Cover image", padding=10)
        left.grid(row=1, column=0, sticky="nsew", padx=(0, 8))
        ttk.Button(left, text="Browse image...", command=self.browse).pack(anchor="w")
        self.path_label = ttk.Label(left, text="No file selected", style="Info.TLabel",
                                    wraplength=380)
        self.path_label.pack(anchor="w", pady=(6, 6))
        self.preview = ImagePreview(left)
        self.preview.pack()
        self.info_label = ttk.Label(left, text="", style="Info.TLabel", wraplength=380,
                                    justify="left")
        self.info_label.pack(anchor="w", pady=(8, 0))

        right = ttk.LabelFrame(self, text="2. Secret message", padding=10)
        right.grid(row=1, column=1, sticky="nsew", padx=(8, 0))
        text_frame = ttk.Frame(right)
        text_frame.pack(fill="both", expand=True)
        self.msg = tk.Text(text_frame, height=8, width=44, wrap="word", font=(FONT, 10),
                           relief="solid", borderwidth=1)
        scroll = ttk.Scrollbar(text_frame, command=self.msg.yview)
        self.msg.configure(yscrollcommand=scroll.set)
        self.msg.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        for event in ("<KeyRelease>", "<<Paste>>", "<<Cut>>"):
            self.msg.bind(event, lambda e: self.after_idle(self.update_counter))
        self.counter = ttk.Label(right, text="Select an image to see capacity.",
                                 style="Info.TLabel")
        self.counter.pack(anchor="w", pady=(4, 8))

        pw_box = ttk.LabelFrame(right, text="Password protection (optional)", padding=8)
        pw_box.pack(fill="x")
        self.use_pw = tk.BooleanVar(value=False)
        ttk.Checkbutton(pw_box, text="Encrypt message with a password", variable=self.use_pw,
                        command=self.toggle_password).grid(row=0, column=0, columnspan=2, sticky="w")
        ttk.Label(pw_box, text="Password:").grid(row=1, column=0, sticky="w", pady=2)
        self.pw = ttk.Entry(pw_box, show="*", width=28, state="disabled")
        self.pw.grid(row=1, column=1, sticky="w", padx=6)
        ttk.Label(pw_box, text="Confirm:").grid(row=2, column=0, sticky="w", pady=2)
        self.pw2 = ttk.Entry(pw_box, show="*", width=28, state="disabled")
        self.pw2.grid(row=2, column=1, sticky="w", padx=6)
        self.show_pw = tk.BooleanVar(value=False)
        ttk.Checkbutton(pw_box, text="Show password", variable=self.show_pw,
                        command=self.toggle_show).grid(row=3, column=1, sticky="w", padx=6)

        buttons = ttk.Frame(right)
        buttons.pack(fill="x", pady=(12, 0))
        ttk.Button(buttons, text="Hide & Save...",
                   style="Accent.TButton", command=self.hide).pack(side="left")
        ttk.Button(buttons, text="Clear message", command=self.clear_message).pack(side="left", padx=6)
        ttk.Button(buttons, text="Reset all", command=self.reset).pack(side="left")

        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(1, weight=1)

    # ---- helpers ----
    def browse(self):
        path = filedialog.askopenfilename(title="Select cover image", filetypes=IMAGE_TYPES)
        if not path:
            return
        try:
            validate_image_path(path)
            with Image.open(path) as img:
                width, height = img.size
            self.preview.show(path)
        except SteganographyError as exc:
            messagebox.showerror("Invalid image", str(exc))
            return
        except Exception as exc:  # unexpected file problems
            messagebox.showerror("Error", f"Could not open the image:\n{exc}")
            return
        self.image_path = path
        self.capacity_bytes = calculate_capacity_bytes(width, height)
        self.path_label.configure(text=path)
        self.info_label.configure(text=(
            f"Dimensions: {width} x {height} px   |   File size: "
            f"{format_size(os.path.getsize(path))}\n"
            f"Capacity: {self.capacity_bytes} bytes total "
            f"({max(self.capacity_bytes - payload_format.HEADER_SIZE, 0)} bytes of plain text "
            f"after the {payload_format.HEADER_SIZE}-byte header)."))
        self.update_counter()
        self.app.set_status(f"Loaded {os.path.basename(path)}")

    def update_counter(self):
        if not self.image_path:
            return
        text = self.msg.get("1.0", "end-1c")
        size = estimate_payload_size(len(text.encode("utf-8")), self.use_pw.get())
        fits = size <= self.capacity_bytes
        self.counter.configure(
            text=f"Characters: {len(text)}   |   Will use {size} of {self.capacity_bytes} bytes "
                 f"({'fits' if fits else 'TOO LARGE'})",
            foreground=OK_GREEN if fits else ERR_RED)

    def toggle_password(self):
        state = "normal" if self.use_pw.get() else "disabled"
        for entry in (self.pw, self.pw2):
            entry.configure(state=state)
            if state == "disabled":
                entry.delete(0, "end")
        self.update_counter()

    def toggle_show(self):
        char = "" if self.show_pw.get() else "*"
        self.pw.configure(show=char)
        self.pw2.configure(show=char)

    def clear_message(self):
        self.msg.delete("1.0", "end")
        self.update_counter()

    def reset(self):
        self.image_path = None
        self.capacity_bytes = 0
        self.preview.clear()
        self.path_label.configure(text="No file selected")
        self.info_label.configure(text="")
        self.counter.configure(text="Select an image to see capacity.", foreground=MUTED)
        self.msg.delete("1.0", "end")
        self.use_pw.set(False)
        self.show_pw.set(False)
        self.toggle_show()
        self.toggle_password()
        self.app.set_status("Ready")

    # ---- main action ----
    def hide(self):
        if not self.image_path:
            messagebox.showwarning("No image", "Please select a cover image first.")
            return
        message = self.msg.get("1.0", "end-1c")
        password = None
        if self.use_pw.get():
            password = self.pw.get()
            if not password:
                messagebox.showwarning("Password needed",
                                       "Enter a password, or untick the encryption option.")
                return
            if password != self.pw2.get():
                messagebox.showwarning("Passwords differ", "The two passwords do not match.")
                return
        try:
            validate_message(message)
            if estimate_payload_size(len(message.encode("utf-8")), password is not None) \
                    > self.capacity_bytes:
                messagebox.showwarning(
                    "Message too large",
                    "This message does not fit in the selected image.\n"
                    "Use a shorter message or a larger image.")
                return
            os.makedirs(OUTPUT_DIR, exist_ok=True)
            out_path = filedialog.asksaveasfilename(
                title="Save encoded image as PNG", initialdir=OUTPUT_DIR,
                initialfile=os.path.basename(default_output_path(self.image_path, OUTPUT_DIR)),
                defaultextension=".png", filetypes=[("PNG image", "*.png")])
            if not out_path:
                return
            self.app.set_status("Hiding message...", busy=True)
            encode_image(self.image_path, out_path, message, password)
        except SteganographyError as exc:
            messagebox.showerror("Cannot hide message", str(exc))
            return
        except Exception as exc:
            messagebox.showerror("Unexpected error", f"Something went wrong:\n{exc}")
            return
        finally:
            self.app.set_status("Ready", busy=False)

        self.app.pages["compare"].prefill(self.image_path, out_path)
        if messagebox.askyesno("Success",
                               f"Message hidden successfully.\n\nSaved to:\n{out_path}\n\n"
                               "Open the quality comparison now?"):
            self.app.show_page("compare")
            self.app.pages["compare"].compare()
        self.app.set_status(f"Saved {os.path.basename(out_path)}")


# =============================================================================
# Extract
# =============================================================================
class ExtractPage(Page):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        self.image_path = None

        ttk.Label(self, text="Extract a Secret Message", style="Title.TLabel").grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))

        left = ttk.LabelFrame(self, text="1. Encoded image", padding=10)
        left.grid(row=1, column=0, sticky="nsew", padx=(0, 8))
        ttk.Button(left, text="Browse encoded PNG...", command=self.browse).pack(anchor="w")
        self.path_label = ttk.Label(left, text="No file selected", style="Info.TLabel",
                                    wraplength=380)
        self.path_label.pack(anchor="w", pady=(6, 6))
        self.preview = ImagePreview(left)
        self.preview.pack()
        self.detect_label = ttk.Label(left, text="", style="Info.TLabel", wraplength=380,
                                      justify="left")
        self.detect_label.pack(anchor="w", pady=(8, 0))

        right = ttk.LabelFrame(self, text="2. Result", padding=10)
        right.grid(row=1, column=1, sticky="nsew", padx=(8, 0))
        row = ttk.Frame(right)
        row.pack(fill="x")
        ttk.Label(row, text="Password (if used):").pack(side="left")
        self.pw = ttk.Entry(row, show="*", width=26)
        self.pw.pack(side="left", padx=6)
        self.show_pw = tk.BooleanVar(value=False)
        ttk.Checkbutton(row, text="Show", variable=self.show_pw,
                        command=lambda: self.pw.configure(
                            show="" if self.show_pw.get() else "*")).pack(side="left")

        buttons = ttk.Frame(right)
        buttons.pack(fill="x", pady=10)
        ttk.Button(buttons, text="Extract message", style="Accent.TButton",
                   command=self.extract).pack(side="left")
        ttk.Button(buttons, text="Copy", command=self.copy).pack(side="left", padx=6)
        ttk.Button(buttons, text="Clear", command=self.clear_result).pack(side="left")
        ttk.Button(buttons, text="Reset all", command=self.reset).pack(side="left", padx=6)

        text_frame = ttk.Frame(right)
        text_frame.pack(fill="both", expand=True)
        self.result = tk.Text(text_frame, height=10, width=44, wrap="word", font=(FONT, 10),
                              relief="solid", borderwidth=1, state="disabled", bg="#FAFBFD")
        scroll = ttk.Scrollbar(text_frame, command=self.result.yview)
        self.result.configure(yscrollcommand=scroll.set)
        self.result.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(1, weight=1)

    def browse(self):
        path = filedialog.askopenfilename(title="Select encoded image", filetypes=STEGO_TYPES)
        if not path:
            return
        try:
            validate_image_path(path, STEGO_EXTENSIONS)
            self.preview.show(path)
        except SteganographyError as exc:
            messagebox.showerror("Cannot use this image", str(exc))
            return
        except Exception as exc:
            messagebox.showerror("Error", f"Could not open the image:\n{exc}")
            return
        self.image_path = path
        self.path_label.configure(text=path)
        self.clear_result()
        self.pw.delete(0, "end")
        try:  # peek at the header to tell the user whether a password is needed
            if is_encrypted(load_stego_array(path)):
                self.detect_label.configure(
                    text="Hidden message detected: password-protected.", foreground=OK_GREEN)
            else:
                self.detect_label.configure(
                    text="Hidden message detected: not password-protected.", foreground=OK_GREEN)
        except SteganographyError as exc:
            self.detect_label.configure(text=str(exc), foreground=ERR_RED)
        self.app.set_status(f"Loaded {os.path.basename(path)}")

    def set_result(self, text):
        self.result.configure(state="normal")
        self.result.delete("1.0", "end")
        self.result.insert("1.0", text)
        self.result.configure(state="disabled")

    def extract(self):
        if not self.image_path:
            messagebox.showwarning("No image", "Please select an encoded image first.")
            return
        password = self.pw.get() or None
        self.app.set_status("Extracting message...", busy=True)
        try:
            text = decode_image(self.image_path, password)
        except PasswordRequiredError as exc:
            messagebox.showwarning("Password required", str(exc))
            self.pw.focus_set()
            return
        except WrongPasswordError as exc:
            messagebox.showerror("Wrong password", str(exc))
            self.pw.focus_set()
            return
        except SteganographyError as exc:
            messagebox.showerror("Cannot extract message", str(exc))
            return
        except Exception as exc:
            messagebox.showerror("Unexpected error", f"Something went wrong:\n{exc}")
            return
        finally:
            self.app.set_status("Ready", busy=False)
        self.set_result(text)
        self.app.set_status("Message extracted successfully")

    def copy(self):
        text = self.result.get("1.0", "end-1c")
        if not text:
            messagebox.showinfo("Nothing to copy", "Extract a message first.")
            return
        self.clipboard_clear()
        self.clipboard_append(text)
        self.app.set_status("Message copied to clipboard")

    def clear_result(self):
        self.set_result("")

    def reset(self):
        self.image_path = None
        self.preview.clear()
        self.path_label.configure(text="No file selected")
        self.detect_label.configure(text="")
        self.pw.delete(0, "end")
        self.show_pw.set(False)
        self.pw.configure(show="*")
        self.clear_result()
        self.app.set_status("Ready")


# =============================================================================
# Compare
# =============================================================================
class ComparePage(Page):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        self.original_path = None
        self.encoded_path = None

        ttk.Label(self, text="Image Quality Comparison", style="Title.TLabel").pack(anchor="w")

        top = ttk.Frame(self)
        top.pack(fill="x", pady=8)
        ttk.Button(top, text="Select original...", command=self.pick_original).pack(side="left")
        self.orig_label = ttk.Label(top, text="(none)", style="Info.TLabel", width=28)
        self.orig_label.pack(side="left", padx=(6, 16))
        ttk.Button(top, text="Select encoded...", command=self.pick_encoded).pack(side="left")
        self.enc_label = ttk.Label(top, text="(none)", style="Info.TLabel", width=28)
        self.enc_label.pack(side="left", padx=6)
        ttk.Button(top, text="Compare", style="Accent.TButton",
                   command=self.compare).pack(side="left", padx=6)
        ttk.Button(top, text="Reset", command=self.reset).pack(side="left")

        body = ttk.Frame(self)
        body.pack(fill="both", expand=True)
        self.fig = Figure(figsize=(7.5, 3.0), dpi=100)
        self.fig.patch.set_facecolor(BG)
        self.canvas = FigureCanvasTkAgg(self.fig, master=body)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)
        self.draw_placeholder()

        bottom = ttk.Frame(self)
        bottom.pack(fill="x", pady=(8, 0))
        self.table = ttk.Treeview(bottom, columns=("metric", "value"), show="headings", height=8)
        self.table.heading("metric", text="Metric")
        self.table.heading("value", text="Value")
        self.table.column("metric", width=210)
        self.table.column("value", width=300)
        self.table.pack(side="left")
        self.explain = ttk.Label(bottom, text="Run a comparison to see what the numbers mean.",
                                 wraplength=300, justify="left", style="Info.TLabel")
        self.explain.pack(side="left", padx=16, anchor="n")

    def prefill(self, original, encoded):
        self.original_path, self.encoded_path = original, encoded
        self.orig_label.configure(text=os.path.basename(original))
        self.enc_label.configure(text=os.path.basename(encoded))

    def pick_original(self):
        path = filedialog.askopenfilename(title="Select original image", filetypes=IMAGE_TYPES)
        if path:
            self.original_path = path
            self.orig_label.configure(text=os.path.basename(path))

    def pick_encoded(self):
        path = filedialog.askopenfilename(title="Select encoded image", filetypes=IMAGE_TYPES)
        if path:
            self.encoded_path = path
            self.enc_label.configure(text=os.path.basename(path))

    def draw_placeholder(self):
        self.fig.clear()
        ax = self.fig.add_subplot(111)
        ax.axis("off")
        ax.set_facecolor(BG)
        ax.text(0.5, 0.5, "Select two images and press Compare", ha="center", va="center",
                color=MUTED, fontsize=11)
        self.canvas.draw_idle()

    def compare(self):
        if not self.original_path or not self.encoded_path:
            messagebox.showwarning("Select images", "Please select both the original and the encoded image.")
            return
        self.app.set_status("Comparing images...", busy=True)
        try:
            result = compare_images(self.original_path, self.encoded_path)
            a = load_rgb_array(self.original_path)
            b = load_rgb_array(self.encoded_path)
        except SteganographyError as exc:
            messagebox.showerror("Cannot compare", str(exc))
            return
        except Exception as exc:
            messagebox.showerror("Unexpected error", f"Something went wrong:\n{exc}")
            return
        finally:
            self.app.set_status("Ready", busy=False)

        # Difference map: pixels that differ at all are shown bright.
        diff = np.abs(a.astype(np.int16) - b.astype(np.int16)).max(axis=2)
        self.fig.clear()
        titles = ["Original", "Encoded", "Changed pixels (highlighted)"]
        for i, (title, data) in enumerate(zip(titles, (a, b, (diff > 0) * 255)), start=1):
            ax = self.fig.add_subplot(1, 3, i)
            if i < 3:
                ax.imshow(data)
            else:
                ax.imshow(data, cmap="magma", vmin=0, vmax=255)
            ax.set_title(title, fontsize=9, color=NAVY)
            ax.axis("off")
        self.fig.tight_layout()
        self.canvas.draw_idle()

        psnr = result["psnr"]
        psnr_text = "infinite (images identical)" if math.isinf(psnr) else f"{psnr:.2f} dB"
        o, e = result["original"], result["encoded"]
        percent = 100.0 * result["changed_values"] / result["total_values"]
        rows = [
            ("Original dimensions", f"{o['width']} x {o['height']} px"),
            ("Encoded dimensions", f"{e['width']} x {e['height']} px"),
            ("Original file size", format_size(o["file_size"])),
            ("Encoded file size", format_size(e["file_size"])),
            ("MSE", f"{result['mse']:.6f}"),
            ("PSNR", psnr_text),
            ("Changed colour values", f"{result['changed_values']} of {result['total_values']} ({percent:.2f}%)"),
            ("Largest change in any value", f"{result['max_difference']} (out of 255)"),
        ]
        self.table.delete(*self.table.get_children())
        for row in rows:
            self.table.insert("", "end", values=row)
        self.explain.configure(text=(
            f"{result['interpretation']}\n\n"
            "MSE is the average squared difference between pixel values (0 = identical). "
            "PSNR = 10*log10(255^2 / MSE); above about 40 dB the change is normally "
            "invisible. LSB changes each value by at most 1."))
        self.app.set_status("Comparison complete")

    def reset(self):
        self.original_path = self.encoded_path = None
        self.orig_label.configure(text="(none)")
        self.enc_label.configure(text="(none)")
        self.table.delete(*self.table.get_children())
        self.explain.configure(text="Run a comparison to see what the numbers mean.")
        self.draw_placeholder()
        self.app.set_status("Ready")


# =============================================================================
# About
# =============================================================================
ABOUT_TEXT = """Secure Image Steganography Using Python

WHAT IT DOES
Hides a text message inside an image and extracts it again. An optional password encrypts the message first.

TECHNOLOGIES
Python 3, Tkinter/ttk (GUI), Pillow (images), NumPy (pixel arrays, metrics), cryptography (Scrypt + Fernet), Matplotlib (comparison charts), unittest (tests).

LSB ALGORITHM
Every pixel has red, green and blue values from 0 to 255. The least significant bit of each value is replaced by one bit of the secret data. Example: 180 = 10110100; hiding bit 1 gives 10110101 = 181. The value changes by at most 1, which the eye cannot see.

PAYLOAD FORMAT
Magic identifier (SIS1) | version | flags | body length | CRC32 checksum | body. The stored length tells the decoder exactly where the message ends.

ENCRYPTION
Password -> Scrypt with a random 16-byte salt -> key -> Fernet (AES + HMAC authentication). The salt is stored in the payload. A wrong password or modified data is rejected.

IMPORTANT
Encryption protects the CONTENT of a message. Steganography conceals that a message EXISTS. Always save as PNG; JPEG compression would destroy the hidden data.

LIMITATIONS
LSB steganography is not undetectable: statistical tools (for example chi-square analysis) can reveal it. Resizing, cropping, filtering or re-saving the image as JPEG destroys the message. Only text is supported.
"""


class AboutPage(Page):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        ttk.Label(self, text="About Project", style="Title.TLabel").pack(anchor="w", pady=(0, 10))
        frame = ttk.Frame(self)
        frame.pack(fill="both", expand=True)
        text = tk.Text(frame, wrap="word", font=(FONT, 10), relief="flat", bg=WHITE,
                       padx=14, pady=10)
        scroll = ttk.Scrollbar(frame, command=text.yview)
        text.configure(yscrollcommand=scroll.set)
        text.insert("1.0", ABOUT_TEXT)
        text.configure(state="disabled")
        text.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")


# =============================================================================
# Main window
# =============================================================================
class App(tk.Tk):
    NAV = [("home", "Home"), ("hide", "Hide Message"), ("extract", "Extract Message"),
           ("compare", "Compare Images"), ("about", "About")]

    def __init__(self):
        super().__init__()
        self.title("Secure Image Steganography")
        self.geometry("1120x760")
        self.minsize(1000, 700)
        configure_styles(self)

        sidebar = tk.Frame(self, bg=NAVY, width=210)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)
        tk.Label(sidebar, text="StegoSecure", bg=NAVY, fg=WHITE,
                 font=(FONT, 16, "bold")).pack(anchor="w", padx=16, pady=(20, 2))
        tk.Label(sidebar, text="LSB image steganography", bg=NAVY, fg="#B7C7DD",
                 font=(FONT, 9)).pack(anchor="w", padx=16, pady=(0, 18))
        self.nav_buttons = {}
        for key, label in self.NAV:
            btn = ttk.Button(sidebar, text=label, style="Nav.TButton",
                             command=lambda k=key: self.show_page(k))
            btn.pack(fill="x")
            self.nav_buttons[key] = btn

        main = ttk.Frame(self)
        main.pack(side="left", fill="both", expand=True)

        status_bar = ttk.Frame(main)
        status_bar.pack(side="bottom", fill="x")
        self.status = ttk.Label(status_bar, text="Ready", style="Info.TLabel", padding=(12, 6))
        self.status.pack(side="left")
        self.progress = ttk.Progressbar(status_bar, mode="indeterminate", length=160)
        self.progress.pack(side="right", padx=12)

        container = ttk.Frame(main)
        container.pack(side="top", fill="both", expand=True)
        container.rowconfigure(0, weight=1)
        container.columnconfigure(0, weight=1)

        self.pages = {
            "home": HomePage(container, self),
            "hide": HidePage(container, self),
            "extract": ExtractPage(container, self),
            "compare": ComparePage(container, self),
            "about": AboutPage(container, self),
        }
        for page in self.pages.values():
            page.grid(row=0, column=0, sticky="nsew")
        self.show_page("home")

    def show_page(self, key):
        self.pages[key].tkraise()
        for name, btn in self.nav_buttons.items():
            btn.configure(style="NavActive.TButton" if name == key else "Nav.TButton")

    def set_status(self, text, busy=False):
        self.status.configure(text=text)
        if busy:
            self.progress.start(12)
        else:
            self.progress.stop()
        self.update_idletasks()


def run():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    App().mainloop()
